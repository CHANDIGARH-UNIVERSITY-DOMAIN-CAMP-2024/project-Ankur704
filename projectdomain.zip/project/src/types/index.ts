export interface EoICategory {
  name: string;
  weight: number;
  score: number;
  metrics: Array<{
    name: string;
    value: number;
    weight: number;
    description: string;
  }>;
}

export interface LocationData {
  id: string;
  name: string;
  categories: EoICategory[];
  totalScore: number;
  timestamp: string;
}