import { EoICategory } from '../types';

export const initialCategories: EoICategory[] = [
  {
    name: 'Housing',
    weight: 0.2,
    score: 0,
    metrics: [
      { name: 'Rent Affordability', value: 0, weight: 0.3, description: 'Average rent compared to local income' },
      { name: 'Power Supply', value: 0, weight: 0.2, description: 'Hours of uninterrupted electricity' },
      { name: 'Water Supply', value: 0, weight: 0.2, description: 'Daily water availability and quality' },
      { name: 'Society Maintenance', value: 0, weight: 0.15, description: 'Building upkeep and amenities' },
      { name: 'Parking Space', value: 0, weight: 0.15, description: 'Availability of parking spots' }
    ]
  },
  {
    name: 'Transportation',
    weight: 0.2,
    score: 0,
    metrics: [
      { name: 'Metro Accessibility', value: 0, weight: 0.3, description: 'Distance to nearest metro station' },
      { name: 'Auto/Rickshaw', value: 0, weight: 0.2, description: 'Availability of local transport' },
      { name: 'Bus Service', value: 0, weight: 0.2, description: 'Frequency and routes of city buses' },
      { name: 'Traffic Congestion', value: 0, weight: 0.15, description: 'Peak hour traffic conditions' },
      { name: 'Road Quality', value: 0, weight: 0.15, description: 'Road maintenance and monsoon readiness' }
    ]
  },
  {
    name: 'Healthcare',
    weight: 0.2,
    score: 0,
    metrics: [
      { name: 'Govt Hospitals', value: 0, weight: 0.25, description: 'Access to government healthcare' },
      { name: 'Private Hospitals', value: 0, weight: 0.25, description: 'Quality private healthcare facilities' },
      { name: 'Pharmacies', value: 0, weight: 0.2, description: '24/7 medicine availability' },
      { name: 'Ambulance Response', value: 0, weight: 0.15, description: 'Emergency response time' },
      { name: 'Clinics', value: 0, weight: 0.15, description: 'Local clinics and dispensaries' }
    ]
  },
  {
    name: 'Education',
    weight: 0.15,
    score: 0,
    metrics: [
      { name: 'School Quality', value: 0, weight: 0.3, description: 'CBSE/ICSE schools in vicinity' },
      { name: 'Coaching Centers', value: 0, weight: 0.2, description: 'Tutorial and test prep centers' },
      { name: 'Higher Education', value: 0, weight: 0.2, description: 'Colleges and universities' },
      { name: 'School Transport', value: 0, weight: 0.15, description: 'School bus services' },
      { name: 'Libraries', value: 0, weight: 0.15, description: 'Public libraries and study spaces' }
    ]
  },
  {
    name: 'Amenities',
    weight: 0.15,
    score: 0,
    metrics: [
      { name: 'Markets', value: 0, weight: 0.25, description: 'Local markets and shopping' },
      { name: 'Parks', value: 0, weight: 0.2, description: 'Green spaces and parks' },
      { name: 'Street Food', value: 0, weight: 0.2, description: 'Local food options' },
      { name: 'Banks/ATMs', value: 0, weight: 0.2, description: 'Banking facilities' },
      { name: 'Internet Speed', value: 0, weight: 0.15, description: 'Broadband connectivity' }
    ]
  },
  {
    name: 'Safety',
    weight: 0.1,
    score: 0,
    metrics: [
      { name: 'Police Station', value: 0, weight: 0.3, description: 'Distance to nearest police station' },
      { name: 'Street Lighting', value: 0, weight: 0.25, description: 'Night time visibility' },
      { name: 'CCTV Coverage', value: 0, weight: 0.2, description: 'Security camera presence' },
      { name: 'Guard Services', value: 0, weight: 0.15, description: 'Society security arrangements' },
      { name: 'Emergency Help', value: 0, weight: 0.1, description: 'SOS response system' }
    ]
  }
];