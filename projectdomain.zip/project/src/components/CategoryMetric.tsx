import React from 'react';
import { EoICategory } from '../types';

interface CategoryMetricProps {
  metric: EoICategory['metrics'][0];
  onChange: (value: number) => void;
}

export default function CategoryMetric({ metric, onChange }: CategoryMetricProps) {
  return (
    <div>
      <div className="flex justify-between mb-2">
        <label className="text-sm font-medium text-gray-700">
          {metric.name}
          <span className="text-gray-500 text-xs ml-2">
            (Weight: {metric.weight})
          </span>
        </label>
        <span className="text-sm text-gray-500">{metric.value}/10</span>
      </div>
      <input
        type="range"
        min="0"
        max="10"
        step="0.1"
        value={metric.value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
      />
      <p className="text-xs text-gray-500 mt-1">{metric.description}</p>
    </div>
  );
}