import React from 'react';
import { Home, Bus, Heart, GraduationCap, Store, Shield, BarChart3 } from 'lucide-react';
import { EoICategory } from '../types';
import CategoryMetric from './CategoryMetric';

interface CategorySectionProps {
  category: EoICategory;
  onMetricChange: (metricIndex: number, value: number) => void;
}

const getCategoryIcon = (name: string) => {
  switch (name.toLowerCase()) {
    case 'housing':
      return <Home className="w-5 h-5" />;
    case 'transportation':
      return <Bus className="w-5 h-5" />;
    case 'healthcare':
      return <Heart className="w-5 h-5" />;
    case 'education':
      return <GraduationCap className="w-5 h-5" />;
    case 'amenities':
      return <Store className="w-5 h-5" />;
    case 'safety':
      return <Shield className="w-5 h-5" />;
    default:
      return <BarChart3 className="w-5 h-5" />;
  }
};

export default function CategorySection({ category, onMetricChange }: CategorySectionProps) {
  return (
    <div className="mb-8 border-b pb-6">
      <div className="flex items-center mb-4">
        {getCategoryIcon(category.name)}
        <h2 className="text-xl font-semibold ml-2">{category.name}</h2>
        <span className="ml-auto text-lg font-medium">
          Score: {category.score.toFixed(2)}
        </span>
      </div>

      <div className="space-y-4">
        {category.metrics.map((metric, index) => (
          <CategoryMetric
            key={metric.name}
            metric={metric}
            onChange={(value) => onMetricChange(index, value)}
          />
        ))}
      </div>
    </div>
  );
}