import React, { useState } from 'react';
import { EoICategory } from '../types';
import { initialCategories } from '../data/categories';
import { calculateCategoryScore, calculateTotalScore } from '../utils/scoring';
import LocationInput from './LocationInput';
import CategorySection from './CategorySection';
import TotalScore from './TotalScore';

export default function Calculator() {
  const [categories, setCategories] = useState<EoICategory[]>(initialCategories);
  const [locationName, setLocationName] = useState('');

  const handleMetricChange = (categoryIndex: number, metricIndex: number, value: number) => {
    const newCategories = [...categories];
    newCategories[categoryIndex].metrics[metricIndex].value = value;
    newCategories[categoryIndex].score = calculateCategoryScore(newCategories[categoryIndex].metrics);
    setCategories(newCategories);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Ease of Living Index Calculator
          </h1>
          <p className="text-lg text-gray-600">
            Evaluate and compare quality of life metrics for different locations
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <LocationInput value={locationName} onChange={setLocationName} />

          {categories.map((category, categoryIndex) => (
            <CategorySection
              key={category.name}
              category={category}
              onMetricChange={(metricIndex, value) => 
                handleMetricChange(categoryIndex, metricIndex, value)
              }
            />
          ))}

          <TotalScore score={calculateTotalScore(categories)} />
        </div>
      </div>
    </div>
  );
}