import React from 'react';

interface TotalScoreProps {
  score: string;
}

export default function TotalScore({ score }: TotalScoreProps) {
  return (
    <div className="mt-8 p-6 bg-gray-50 rounded-lg">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-gray-900">Total EoI Score</h3>
        <span className="text-3xl font-bold text-blue-600">{score}</span>
      </div>
    </div>
  );
}