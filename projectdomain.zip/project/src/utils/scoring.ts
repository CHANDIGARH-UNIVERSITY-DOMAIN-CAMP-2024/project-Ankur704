import { EoICategory } from '../types';

export const calculateCategoryScore = (metrics: EoICategory['metrics']): number => {
  return metrics.reduce((acc, metric) => acc + (metric.value * metric.weight), 0);
};

export const calculateTotalScore = (categories: EoICategory[]): string => {
  return categories
    .reduce((acc, category) => acc + (category.score * category.weight), 0)
    .toFixed(2);
};